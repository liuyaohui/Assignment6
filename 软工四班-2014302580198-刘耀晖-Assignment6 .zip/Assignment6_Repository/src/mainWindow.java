import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class mainWindow {
	private JFrame mainWindow;
	private JTextField searchField;
	private JButton searchButton,infoButton,backButton,cartButton;
	private JButton dogButton,catButton,hamsterButton,parrotButton,fishButton,rabbitButton,squirrelButton,canaryButton,turtleButton,lizardButton,mynaButton,snakeButton;
	private JLabel mainBackground,ldog,lcat,lhamster,lparrot,lfish,lrabbit,lsquirrel,lcanary,lturtle,llizard,lmyna,lsnake;
	private JLabel j1,j2,j3,j4,j5,j6,j7,j8,j9,j10,j11,j12;
	private Icon iconMBG,iconDog,iconCat,iconHamster,iconParrot,iconFish,iconRabbit,iconSquirrel,iconCanary,iconTurtle,iconLizard,iconMyna,iconSnake;
	public static int flag = 0;
	public mainWindow(){
		mainWindow = new JFrame("Pet House");
		mainWindow.setSize(900, 600);
		mainWindow.setLayout(null);
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainWindow.setVisible(true);
		mainWindow.setResizable(false);
		
		searchField = new JTextField("���ͼƬ��ֱ�Ӳ鿴��ϸ��Ϣ");
		searchField.setBounds(275, 35, 360, 35);
		
		searchButton = new JButton("search");
		searchButton.setBounds(640, 37, 80, 30);
		searchButton.setFocusPainted(false);
		//searchButton.setContentAreaFilled(false);
		searchButton.setDoubleBuffered(true);
		searchButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		infoButton = new JButton("Person Info");
		infoButton.setBounds(725, 37, 115, 30);
		infoButton.setFocusPainted(false);
		//infoButton.setContentAreaFilled(false);
		infoButton.setDoubleBuffered(true);
		infoButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		backButton = new JButton("Quit");
		backButton.setBounds(780, 500, 80, 30);
		backButton.setFocusPainted(false);
		//backButton.setContentAreaFilled(false);
		backButton.setDoubleBuffered(true);
		backButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		cartButton = new JButton("Shopping cart");
		cartButton.setBounds(620, 500, 150, 30);
		cartButton.setFocusPainted(false);
		//cartButton.setContentAreaFilled(false);
		cartButton.setDoubleBuffered(true);
		cartButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		mainBackground = new JLabel();
		mainBackground.setBounds(0, 0, 900, 600);
		iconMBG = new ImageIcon(this.getClass().getResource("2.jpg"));
		mainBackground.setIcon(iconMBG);
		
		ldog = new JLabel();
		ldog.setBounds(100, 90, 121, 121);
		iconDog = new ImageIcon(this.getClass().getResource("dog.jpg"));
		ldog.setIcon(iconDog);
		j1 = new JLabel("Dog");
		j1.setBounds(147, 215, 50, 20);
		dogButton = new JButton();
		dogButton.setBounds(100, 90, 121, 121);
		dogButton.setFocusPainted(false);
		dogButton.setContentAreaFilled(false);
		dogButton.setDoubleBuffered(true);
		
		lcat = new JLabel();
		lcat.setBounds(250, 90, 121, 121);
		iconCat = new ImageIcon(this.getClass().getResource("cat.jpg"));
		lcat.setIcon(iconCat);
		j2 = new JLabel("Cat");
		j2.setBounds(298, 215, 50, 20);
		catButton = new JButton();
		catButton.setBounds(250, 90, 121, 121);
		catButton.setFocusPainted(false);
		catButton.setContentAreaFilled(false);
		catButton.setDoubleBuffered(true);
		
		lhamster = new JLabel();
		lhamster.setBounds(400, 90, 121, 121);
		iconHamster = new ImageIcon(this.getClass().getResource("hamster.jpg"));
		lhamster.setIcon(iconHamster);
		j3 = new JLabel("Hamster");
		j3.setBounds(444, 215, 50, 20);
		hamsterButton = new JButton();
		hamsterButton.setBounds(400, 90, 121, 121);
		hamsterButton.setFocusPainted(false);
		hamsterButton.setContentAreaFilled(false);
		hamsterButton.setDoubleBuffered(true);
		
		lparrot = new JLabel();
		lparrot.setBounds(550, 90, 121, 121);
		iconParrot = new ImageIcon(this.getClass().getResource("parrot.jpg"));
		lparrot.setIcon(iconParrot);
		j4 = new JLabel("Parrot");
		j4.setBounds(595, 215, 50, 20);
		parrotButton = new JButton();
		parrotButton.setBounds(550, 90, 121, 121);
		parrotButton.setFocusPainted(false);
		parrotButton.setContentAreaFilled(false);
		parrotButton.setDoubleBuffered(true);
		
		lfish = new JLabel();
		lfish.setBounds(700, 90, 121, 121);
		iconFish = new ImageIcon(this.getClass().getResource("fish.jpg"));
		lfish.setIcon(iconFish);
		j5 = new JLabel("Fish");
		j5.setBounds(747, 215, 50, 20);
		fishButton = new JButton();
		fishButton.setBounds(700, 90, 121, 121);
		fishButton.setFocusPainted(false);
		fishButton.setContentAreaFilled(false);
		fishButton.setDoubleBuffered(true);
		
		lrabbit = new JLabel();
		lrabbit.setBounds(100, 250, 121, 121);
		iconRabbit = new ImageIcon(this.getClass().getResource("rabbit.jpg"));
		lrabbit.setIcon(iconRabbit);
		j6 = new JLabel("Rabbit");
		j6.setBounds(145, 375, 50, 20);
		rabbitButton = new JButton();
		rabbitButton.setBounds(100, 250, 121, 121);
		rabbitButton.setFocusPainted(false);
		rabbitButton.setContentAreaFilled(false);
		rabbitButton.setDoubleBuffered(true);
		
		lsquirrel = new JLabel();
		lsquirrel.setBounds(250, 250, 121, 121);
		iconSquirrel = new ImageIcon(this.getClass().getResource("squirrel.jpg"));
		lsquirrel.setIcon(iconSquirrel);
		j7 = new JLabel("Squirrel");
		j7.setBounds(293, 375, 50, 20);
		squirrelButton = new JButton();
		squirrelButton.setBounds(250, 250, 121, 121);
		squirrelButton.setFocusPainted(false);
		squirrelButton.setContentAreaFilled(false);
		squirrelButton.setDoubleBuffered(true);
		
		lcanary = new JLabel();
		lcanary.setBounds(400, 250, 121, 121);
		iconCanary = new ImageIcon(this.getClass().getResource("canary.jpg"));
		lcanary.setIcon(iconCanary);
		j8 = new JLabel("Canary");
		j8.setBounds(445, 375, 50, 20);
		canaryButton = new JButton();
		canaryButton.setBounds(400, 250, 121, 121);
		canaryButton.setFocusPainted(false);
		canaryButton.setContentAreaFilled(false);
		canaryButton.setDoubleBuffered(true);
		
		lturtle = new JLabel();
		lturtle.setBounds(550, 250, 121, 121);
		iconTurtle = new ImageIcon(this.getClass().getResource("turtle.jpg"));
		lturtle.setIcon(iconTurtle);
		j9 = new JLabel("Turtle");
		j9.setBounds(595, 375, 50, 20);
		turtleButton = new JButton();
		turtleButton.setBounds(550, 250, 121, 121);
		turtleButton.setFocusPainted(false);
		turtleButton.setContentAreaFilled(false);
		turtleButton.setDoubleBuffered(true);
		
		llizard = new JLabel();
		llizard.setBounds(700, 250, 121, 121);
		iconLizard = new ImageIcon(this.getClass().getResource("lizard.jpg"));
		llizard.setIcon(iconLizard);
		j10 = new JLabel("Lizard");
		j10.setBounds(745, 375, 50, 20);
		lizardButton = new JButton();
		lizardButton.setBounds(700, 250, 121, 121);
		lizardButton.setFocusPainted(false);
		lizardButton.setContentAreaFilled(false);
		lizardButton.setDoubleBuffered(true);
		
		lmyna = new JLabel();
		lmyna.setBounds(100, 410, 121, 121);
		iconMyna = new ImageIcon(this.getClass().getResource("myna.jpg"));
		lmyna.setIcon(iconMyna);
		j11 = new JLabel("Myna");
		j11.setBounds(145, 535, 50, 20);
		mynaButton = new JButton();
		mynaButton.setBounds(100, 410, 121, 121);
		mynaButton.setFocusPainted(false);
		mynaButton.setContentAreaFilled(false);
		mynaButton.setDoubleBuffered(true);
		
		lsnake = new JLabel();
		lsnake.setBounds(250, 410, 121, 121);
		iconSnake = new ImageIcon(this.getClass().getResource("snake.jpg"));
		lsnake.setIcon(iconSnake);
		j12 = new JLabel("Snake");
		j12.setBounds(295, 535, 50, 20);
		snakeButton = new JButton();
		snakeButton.setBounds(250, 410, 121, 121);
		snakeButton.setFocusPainted(false);
		snakeButton.setContentAreaFilled(false);
		snakeButton.setDoubleBuffered(true);
		
		mainWindow.add(searchField);
		mainWindow.add(searchButton);
		mainWindow.add(cartButton);
		mainWindow.add(infoButton);
		mainWindow.add(ldog);
		mainWindow.add(dogButton);
		mainWindow.add(lcat);
		mainWindow.add(catButton);
		mainWindow.add(lhamster);
		mainWindow.add(hamsterButton);
		mainWindow.add(lparrot);
		mainWindow.add(parrotButton);
		mainWindow.add(lfish);
		mainWindow.add(fishButton);
		mainWindow.add(lrabbit);
		mainWindow.add(rabbitButton);
		mainWindow.add(lsquirrel);
		mainWindow.add(squirrelButton);
		mainWindow.add(lcanary);
		mainWindow.add(canaryButton);
		mainWindow.add(lturtle);
		mainWindow.add(turtleButton);
		mainWindow.add(llizard);
		mainWindow.add(lizardButton);
		mainWindow.add(lmyna);
		mainWindow.add(mynaButton);
		mainWindow.add(lsnake);
		mainWindow.add(snakeButton);
		mainWindow.add(j1);
		mainWindow.add(j2);
		mainWindow.add(j3);
		mainWindow.add(j4);
		mainWindow.add(j5);
		mainWindow.add(j6);
		mainWindow.add(j7);
		mainWindow.add(j8);
		mainWindow.add(j9);
		mainWindow.add(j10);
		mainWindow.add(j11);
		mainWindow.add(j12);
		mainWindow.add(backButton);
		mainWindow.add(mainBackground);
		
		
		//����������ť����¼�
				searchButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	if(searchField.getText().equals("dog")){
		            		flag = 1;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("cat")){
		            		flag = 2;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("hamster")){
		            		flag = 3;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("parrot")){
		            		flag = 4;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("fish")){
		            		flag = 5;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("rabbit")){
		            		flag = 6;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("squirrel")){
		            		flag = 7;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("canary")){
		            		flag = 8;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("turtle")){
		            		flag = 9;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("lizard")){
		            		flag = 10;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("myna")){
		            		flag = 11;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else if(searchField.getText().equals("snake")){
		            		flag = 12;
		            		mainWindow.setVisible(false);
			            	new petWindow();
		            	}
		            	else JOptionPane.showMessageDialog(null, "�ף��Բ���û���ҵ���ֻ����","",JOptionPane.WARNING_MESSAGE);
		            	
		            }
		        });
				//�������ﳵ��ť����¼�
				cartButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	petWindow.cartLocation++;
		            	mainWindow.setVisible(false);
		            	new cartCheckWindow();
		            }
		        });
				//�����س��¼�
				searchField.addKeyListener(new KeyListener(){
					public void keyPressed(KeyEvent  e){
						if(e.getSource() == searchField)
						  {
						   //�жϰ��µļ��Ƿ��ǻس���
						   if(e.getKeyCode() == KeyEvent.VK_ENTER) {
							   if(searchField.getText().equals("dog")){
				            		flag = 1;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("cat")){
				            		flag = 2;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("hamster")){
				            		flag = 3;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("parrot")){
				            		flag = 4;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("fish")){
				            		flag = 5;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("rabbit")){
				            		flag = 6;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("squirrel")){
				            		flag = 7;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("canary")){
				            		flag = 8;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("turtle")){
				            		flag = 9;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("lizard")){
				            		flag = 10;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("myna")){
				            		flag = 11;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else if(searchField.getText().equals("snake")){
				            		flag = 12;
				            		mainWindow.setVisible(false);
					            	new petWindow();
				            	}
				            	else JOptionPane.showMessageDialog(null, "�ף��Բ���û���ҵ���ֻ����","",JOptionPane.WARNING_MESSAGE);
						   }
						}
					}

					@Override
					public void keyReleased(KeyEvent e) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void keyTyped(KeyEvent e) {
						// TODO Auto-generated method stub
						
					}
				});
		//�����˳���ť����¼�
				backButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	int res = JOptionPane.showConfirmDialog(null,"ȷ���˳���¼��?",
		                "",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
		            	if(res == JOptionPane.YES_OPTION){
		            		petWindow.cartLocation = 0;
		            		petWindow.total = 0;
		            		mainWindow.setVisible(false);
		            		new logInWindow();
		            	}
		            }
		        });
		//����ͼƬ��ť����¼�
				dogButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 1;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				catButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 2;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				hamsterButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 3;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				parrotButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 4;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				fishButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 5;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				rabbitButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 6;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				squirrelButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 7;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				canaryButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 8;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				turtleButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 9;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				lizardButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 10;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				mynaButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 11;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
				snakeButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	flag = 12;
	            		mainWindow.setVisible(false);
		            	new petWindow();
		            }
		        });
		//����������Ϣ��ť����¼�
				infoButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	mainWindow.setVisible(false);
		            	new userWindow();
		            }
		        });
		
		//ʹ���ڴ���ʾ���м䵯��
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = mainWindow.getSize();
		if (frameSize.height > screenSize.height)
		    frameSize.height = screenSize.height;       
		if (frameSize.width > screenSize.width)
		    frameSize.width = screenSize.width;       
		mainWindow.setLocation((screenSize.width-frameSize.width)/2,(screenSize.height-frameSize.height) / 2);
	}
}
