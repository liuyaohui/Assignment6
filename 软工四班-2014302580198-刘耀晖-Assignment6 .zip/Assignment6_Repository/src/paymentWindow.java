import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class paymentWindow {
	private JFrame paymentWindow;
	private JTextField addressField,zipField,phoneField;
	private JButton payButton,backButton;
	private JLabel jBackground,jTotal,jAddress,jZip,jPhone,jTitle;
	private Icon iconBG;
	public paymentWindow(){
		paymentWindow = new JFrame("Pet House");
		paymentWindow.setSize(800, 500);
		paymentWindow.setLayout(null);
		paymentWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		backButton = new JButton("Back");
		backButton.setBounds(600, 270, 90, 30);
		backButton.setFocusPainted(false);
		backButton.setContentAreaFilled(false);
		backButton.setDoubleBuffered(true);
		backButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		payButton = new JButton("Pay");
		payButton.setBounds(500, 270, 90, 30);
		payButton.setFocusPainted(false);
		payButton.setContentAreaFilled(false);
		payButton.setDoubleBuffered(true);
		payButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		jTitle = new JLabel("Please fill an order");
		jTotal = new JLabel("Total price: "+petWindow.total+" RMB");
		jAddress = new JLabel("Address:");
		addressField = new JTextField();
		jZip = new JLabel("Zip code:");
		zipField = new JTextField();
		jPhone = new JLabel("Cellphone:");
		phoneField = new JTextField();
		jTotal.setFont(new Font("Tahoma", Font.BOLD, 13));
		jAddress.setFont(new Font("Tahoma", Font.BOLD, 13));
		jZip.setFont(new Font("Tahoma", Font.BOLD, 13));
		jPhone.setFont(new Font("Tahoma", Font.BOLD, 13));
		jTitle.setFont(new Font("Tahoma", Font.BOLD, 15));
		jTitle.setBounds(510,120,200,30);
		jTotal.setBounds(430,150,200,30);
		jAddress.setBounds(430,180,70,30);
		addressField.setBounds(505, 180, 180, 30);
		jZip.setBounds(430,210,70,30);
		zipField.setBounds(505, 210, 180, 30);
		jPhone.setBounds(430,240,70,30);
		phoneField.setBounds(505, 240, 180, 30);
		
		jBackground = new JLabel();
		jBackground.setBounds(0, 0, 800, 500);
		iconBG = new ImageIcon(this.getClass().getResource("1.jpg"));
		jBackground.setIcon(iconBG);
		
		paymentWindow.add(jTitle);
		paymentWindow.add(jTotal);
		paymentWindow.add(jAddress);
		paymentWindow.add(jZip);
		paymentWindow.add(jPhone);
		paymentWindow.add(addressField);
		paymentWindow.add(zipField);
		paymentWindow.add(phoneField);
		paymentWindow.add(backButton);
		paymentWindow.add(payButton);
		paymentWindow.add(jBackground);
		
		paymentWindow.setVisible(true);
		paymentWindow.setResizable(false);
		
		//�������ذ�ť����¼�
				backButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	paymentWindow.setVisible(false);
		            	if(logInWindow.c == 0){
		            		new cartWindow();
		            	}
		            	else{
		            		logInWindow.c--;
		            		new cartCheckWindow();
		            	}
		            }
		        });
		//����ȷ����ť����¼�
				payButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	if(checkAddress() && checkZip() && checkPhone()){
			            	int i = logInWindow.userinfo.getBalance() - petWindow.total;
			            	if(i >= 0){
			            		JOptionPane.showMessageDialog(null, "֧���ɹ�,���ص����ﳵ","",JOptionPane.WARNING_MESSAGE);
			            		logInWindow.userinfo.setBalance(i);
			            		try {
			            			write(i);
			            		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException
			            				| SQLException e1) {
			            			// TODO Auto-generated catch block
			            			e1.printStackTrace();
			            		}
			            		paymentWindow.setVisible(false);
			            		if(logInWindow.c == 0){
				            		new cartWindow();
				            	}
				            	else{
				            		logInWindow.c--;
				            		new cartCheckWindow();
				            	}
			            	}
			            	else JOptionPane.showMessageDialog(null, "��Ǹ���������㣬�޷����֧��","",JOptionPane.WARNING_MESSAGE);
			            }
		            	else{
		            		 	boolean b1=checkAddress();
				    		    boolean b2=checkZip();
				    		    boolean b3=checkPhone();
				    		    if(!b1) {
				    		    	JOptionPane.showMessageDialog(null, "��ַ���ڼ�","",JOptionPane.WARNING_MESSAGE);
				    		    	addressField.setText("");
				    		    }
				    		    if(!b2) {
				    		    	JOptionPane.showMessageDialog(null, "�ʱ಻��ȷ","",JOptionPane.WARNING_MESSAGE);
				    		    	zipField.setText("");
				    		    }
				    		    if(!b3) {
				    		    	JOptionPane.showMessageDialog(null, "�ֻ��Ų���ȷ","",JOptionPane.WARNING_MESSAGE);
				    		    	phoneField.setText("");
				    		    }
		            	}
		            }
		          });
		//ʹ���ڴ���ʾ���м䵯��
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				Dimension frameSize = paymentWindow.getSize();
				if (frameSize.height > screenSize.height)
				    frameSize.height = screenSize.height;       
				if (frameSize.width > screenSize.width)
				    frameSize.width = screenSize.width;       
				paymentWindow.setLocation((screenSize.width-frameSize.width)/2,(screenSize.height-frameSize.height) / 2);
	}
	public void write(int i)throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		//д�����ݿ�
		 Connection conn;  
		 Statement stmt;
		 Class.forName("com.mysql.jdbc.Driver").newInstance(); 
		 conn = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/heavy's", "root", "123456");
		 //ִ��SQL��� 
		 stmt = (Statement) conn.createStatement();
		 String sql = "update userinfo set ��� = '"+ i + "'where �û��� ='"+logInWindow.userinfo.getName()+"'";
		 stmt.execute(sql);
	}
	public boolean checkAddress() {
		  String s1 = addressField.getText();
		  if(s1.length() >= 4)
		   return true;
		  else 
		   return false;
		 }
	public boolean checkZip() {
		  String s1 = zipField.getText();
		  if(s1.length() == 6)
		   return true;
		  else 
		   return false;
		 }
	public boolean checkPhone() {
		  String s1 = phoneField.getText();
		  if(s1.length() == 11)
		   return true;
		  else 
		   return false;
		 }
}
