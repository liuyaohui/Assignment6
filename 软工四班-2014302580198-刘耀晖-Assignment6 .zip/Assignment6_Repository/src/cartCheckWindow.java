import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class cartCheckWindow {
	private JFrame cartWindow;
	private JButton backButton,paymentButton;
	private JLabel background,label_1,label_2,label_3,label_word,label_4,label_5,label_cart;
	private Icon iconBackground,iconCart,iconWord,iconDog,iconCat,iconHamster,iconParrot,iconFish,iconRabbit,iconSquirrel,iconCanary,iconTurtle,iconLizard,iconMyna,iconSnake;
	
	public cartCheckWindow(){
		cartWindow = new JFrame("Pet House");
		cartWindow.setSize(900, 600);
		cartWindow.setLayout(null);
		cartWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cartWindow.setVisible(true);
		cartWindow.setResizable(false);
		
		backButton = new JButton("Back");
		backButton.setBounds(780, 500, 80, 30);
		backButton.setFocusPainted(false);
		//backButton.setContentAreaFilled(false);
		backButton.setDoubleBuffered(true);
		backButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		paymentButton = new JButton("Payment");
		paymentButton.setBounds(620, 500, 150, 30);
		paymentButton.setFocusPainted(false);
		//paymentButton.setContentAreaFilled(false);
		paymentButton.setDoubleBuffered(true);
		paymentButton.setFont(new Font("Tahoma", Font.BOLD, 17));
		
		background = new JLabel();
		background.setBounds(0, 0, 900, 600);
		iconBackground = new ImageIcon(this.getClass().getResource("2.jpg"));
		background.setIcon(iconBackground);
		
		label_cart = new JLabel();
		label_cart.setBounds(50, 120,80,72);
		iconCart = new ImageIcon(this.getClass().getResource("cart.png"));
		label_cart.setIcon(iconCart);
		
		label_word = new JLabel();
		label_word.setBounds(130, 140,400,80);
		iconWord = new ImageIcon(this.getClass().getResource("word.png"));
		label_word.setIcon(iconWord);
		
		iconDog = new ImageIcon(this.getClass().getResource("dog.jpg"));
		iconCat = new ImageIcon(this.getClass().getResource("cat.jpg"));
		iconHamster = new ImageIcon(this.getClass().getResource("hamster.jpg"));
		iconParrot = new ImageIcon(this.getClass().getResource("parrot.jpg"));
		iconFish = new ImageIcon(this.getClass().getResource("fish.jpg"));
		iconRabbit = new ImageIcon(this.getClass().getResource("rabbit.jpg"));
		iconSquirrel = new ImageIcon(this.getClass().getResource("squirrel.jpg"));
		iconCanary = new ImageIcon(this.getClass().getResource("canary.jpg"));
		iconTurtle = new ImageIcon(this.getClass().getResource("turtle.jpg"));
		iconLizard = new ImageIcon(this.getClass().getResource("lizard.jpg"));
		iconMyna = new ImageIcon(this.getClass().getResource("myna.jpg"));
		iconSnake = new ImageIcon(this.getClass().getResource("snake.jpg"));
		
		label_1 = new JLabel();
		label_1.setBounds(100, 220, 121, 121);
		cartWindow.add(label_1);
		label_2 = new JLabel();
		label_2.setBounds(250, 220, 121, 121);
		cartWindow.add(label_2);
		label_3 = new JLabel();
		label_3.setBounds(400, 220, 121, 121);
		cartWindow.add(label_3);
		label_4 = new JLabel();
		label_4.setBounds(550, 220, 121, 121);
		cartWindow.add(label_4);
		label_5 = new JLabel();
		label_5.setBounds(700, 220, 121, 121);
		cartWindow.add(label_5);
		
		if(petWindow.cartLocation == 1){
			cartInfo.a = mainWindow.flag;
		}
		if(petWindow.cartLocation == 2){
			cartInfo.b = mainWindow.flag;
		}
		if(petWindow.cartLocation == 3){
			cartInfo.c = mainWindow.flag;
		}
		if(petWindow.cartLocation == 4){
			cartInfo.d = mainWindow.flag;
		}
		if(petWindow.cartLocation == 5){
			cartInfo.e = mainWindow.flag;
		}
		
		if(petWindow.cartLocation >= 1){
			switch(cartInfo.a){
				case 1:label_1.setIcon(iconDog);break;
				case 2:label_1.setIcon(iconCat);break;
				case 3:label_1.setIcon(iconHamster);break;
				case 4:label_1.setIcon(iconParrot);break;
				case 5:label_1.setIcon(iconFish);break;
				case 6:label_1.setIcon(iconRabbit);break;
				case 7:label_1.setIcon(iconSquirrel);break;
				case 8:label_1.setIcon(iconCanary);break;
				case 9:label_1.setIcon(iconTurtle);break;
				case 10:label_1.setIcon(iconLizard);break;
				case 11:label_1.setIcon(iconMyna);break;
				case 12:label_1.setIcon(iconSnake);break;
			}
		}
		if(petWindow.cartLocation >= 2){
			switch(cartInfo.b){
				case 1:label_2.setIcon(iconDog);break;
				case 2:label_2.setIcon(iconCat);break;
				case 3:label_2.setIcon(iconHamster);break;
				case 4:label_2.setIcon(iconParrot);break;
				case 5:label_2.setIcon(iconFish);break;
				case 6:label_2.setIcon(iconRabbit);break;
				case 7:label_2.setIcon(iconSquirrel);break;
				case 8:label_2.setIcon(iconCanary);break;
				case 9:label_2.setIcon(iconTurtle);break;
				case 10:label_2.setIcon(iconLizard);break;
				case 11:label_2.setIcon(iconMyna);break;
				case 12:label_2.setIcon(iconSnake);break;
			}
		}
		if(petWindow.cartLocation >= 3){
			switch(cartInfo.c){
				case 1:label_3.setIcon(iconDog);break;
				case 2:label_3.setIcon(iconCat);break;
				case 3:label_3.setIcon(iconHamster);break;
				case 4:label_3.setIcon(iconParrot);break;
				case 5:label_3.setIcon(iconFish);break;
				case 6:label_3.setIcon(iconRabbit);break;
				case 7:label_3.setIcon(iconSquirrel);break;
				case 8:label_3.setIcon(iconCanary);break;
				case 9:label_3.setIcon(iconTurtle);break;
				case 10:label_3.setIcon(iconLizard);break;
				case 11:label_3.setIcon(iconMyna);break;
				case 12:label_3.setIcon(iconSnake);break;
			}
		}
		if(petWindow.cartLocation >= 4){
			switch(cartInfo.d){
				case 1:label_4.setIcon(iconDog);break;
				case 2:label_4.setIcon(iconCat);break;
				case 3:label_4.setIcon(iconHamster);break;
				case 4:label_4.setIcon(iconParrot);break;
				case 5:label_4.setIcon(iconFish);break;
				case 6:label_4.setIcon(iconRabbit);break;
				case 7:label_4.setIcon(iconSquirrel);break;
				case 8:label_4.setIcon(iconCanary);break;
				case 9:label_4.setIcon(iconTurtle);break;
				case 10:label_4.setIcon(iconLizard);break;
				case 11:label_4.setIcon(iconMyna);break;
				case 12:label_4.setIcon(iconSnake);break;
			}
		}
		if(petWindow.cartLocation >= 5){
			switch(cartInfo.e){
				case 1:label_5.setIcon(iconDog);break;
				case 2:label_5.setIcon(iconCat);break;
				case 3:label_5.setIcon(iconHamster);break;
				case 4:label_5.setIcon(iconParrot);break;
				case 5:label_5.setIcon(iconFish);break;
				case 6:label_5.setIcon(iconRabbit);break;
				case 7:label_5.setIcon(iconSquirrel);break;
				case 8:label_5.setIcon(iconCanary);break;
				case 9:label_5.setIcon(iconTurtle);break;
				case 10:label_5.setIcon(iconLizard);break;
				case 11:label_5.setIcon(iconMyna);break;
				case 12:label_5.setIcon(iconSnake);break;
			}
		}
		//�������ť����¼�
				paymentButton.addActionListener(new ActionListener() {
		
		            public void actionPerformed(ActionEvent e)
		            {	
		            	logInWindow.c++;
		            	cartWindow.setVisible(false);
		            	new paymentWindow();
		            }
		        });
		//�������ذ�ť����¼�
				backButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	petWindow.cartLocation--;
		            	cartWindow.setVisible(false);
		            	new mainWindow();
		            }
		        });
		
		cartWindow.add(backButton);
		cartWindow.add(paymentButton);
		cartWindow.add(label_cart);
		cartWindow.add(label_word);
		cartWindow.add(background);
		
		//ʹ���ڴ���ʾ���м䵯��
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				Dimension frameSize = cartWindow.getSize();
				if (frameSize.height > screenSize.height)
				    frameSize.height = screenSize.height;       
				if (frameSize.width > screenSize.width)
				    frameSize.width = screenSize.width;       
				cartWindow.setLocation((screenSize.width-frameSize.width)/2,(screenSize.height-frameSize.height) / 2);
	}
}
