import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.mail.MessagingException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class registerWindow {
	private JFrame registerWindow;
	private JTextField idField;
	public static JTextField emailField;
	private JPasswordField passField,repassField;
	private JButton registerButton,backButton;
	private JLabel jId,jPass,jRepass,jEmail,jBackground;
	private Icon iconBG;
	public registerWindow(){
		registerWindow = new JFrame("Pet House");
		registerWindow.setSize(800, 500);
		registerWindow.setLayout(null);
		registerWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		registerWindow.setVisible(true);
		registerWindow.setResizable(false);
		
		idField = new JTextField();
		idField.setBounds(500, 120, 190, 30);
		passField = new JPasswordField();
		passField.setBounds(500, 160, 190, 30);
		repassField = new JPasswordField();
		repassField.setBounds(500, 200, 190, 30);
		emailField = new JTextField();
		emailField.setBounds(500, 240, 190, 30); 
		
		jId = new JLabel("Username:");
		jPass = new JLabel("Password:");
		jRepass = new JLabel("Confirm:");
		jEmail = new JLabel("E-mail:");
		jId.setBounds(430,120,70,30);
		jPass.setBounds(430,160,70,30);
		jRepass.setBounds(430,200,70,30);
		jEmail.setBounds(430,240,70,30);
		jId.setFont(new Font("Tahoma", Font.BOLD, 13));
		jPass.setFont(new Font("Tahoma", Font.BOLD, 13));
		jRepass.setFont(new Font("Tahoma", Font.BOLD, 13));
		jEmail.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		registerButton = new JButton("Register");
		registerButton.setBounds(500, 270, 90, 30);
		registerButton.setFocusPainted(false);
		registerButton.setContentAreaFilled(false);
		registerButton.setDoubleBuffered(true);
		registerButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		backButton = new JButton("Back");
		backButton.setBounds(600, 270, 90, 30);
		backButton.setFocusPainted(false);
		backButton.setContentAreaFilled(false);
		backButton.setDoubleBuffered(true);
		backButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		jBackground = new JLabel();
		jBackground.setBounds(0, 0, 800, 500);
		iconBG = new ImageIcon(this.getClass().getResource("1.jpg"));
		jBackground.setIcon(iconBG);
		
		registerWindow.add(registerButton);
		registerWindow.add(backButton);
		registerWindow.add(idField);
		registerWindow.add(passField);
		registerWindow.add(repassField);
		registerWindow.add(emailField);
		registerWindow.add(jId);
		registerWindow.add(jPass);
		registerWindow.add(jRepass);
		registerWindow.add(jEmail);
		registerWindow.add(jBackground);
		
		//�������ذ�ť����¼�
		backButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {	
            	registerWindow.setVisible(false);
            	new logInWindow();
            }
        });
		//����ע�ᰴť����¼�
		registerButton.addActionListener(new ActionListener() {

		    public void actionPerformed(ActionEvent e)
		    {	
		    	 if(checkEmail()&&checkPassword()&&checkID()&&checkPasswordLength()&&!checkExist()) {
		    		 try {
						new Sendmail();
					} catch (MessagingException e1) {
						e1.printStackTrace();
					}
		    		 try {
						check();
					} catch (InstantiationException | IllegalAccessException | ClassNotFoundException
							| SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		    	 }
		    	 else {
		    		    boolean b1=checkPassword();
		    		    boolean b2=checkEmail();
		    		    boolean b3=checkID();
		    		    boolean b4=checkPasswordLength();
		    		    boolean b5=checkExist();
		    		    if(b5) {
		    		    	JOptionPane.showMessageDialog(null, "�û����Ѵ���","",JOptionPane.WARNING_MESSAGE);
		    		    	idField.setText("");
		    		    }
		    		    if(!b3) {
		    		    	JOptionPane.showMessageDialog(null, "�û������ڼ��","",JOptionPane.WARNING_MESSAGE);
		    		    	idField.setText("");
		    		    }
		    		    if(!b4) {
		    		    	JOptionPane.showMessageDialog(null, "������ڼ�","",JOptionPane.WARNING_MESSAGE);
		    		    	passField.setText("");
		    				repassField.setText("");
		    		    }
		    		    if(!b1) {
		    		    	JOptionPane.showMessageDialog(null, "�����������벻һ��","",JOptionPane.WARNING_MESSAGE);
		    		    	passField.setText("");
		    				repassField.setText("");
		    		    }
		    		    if(!b2) {
		    		    	JOptionPane.showMessageDialog(null, "�����ʼ���ʽ����ȷ","",JOptionPane.WARNING_MESSAGE);
		    		    	emailField.setText("");
		    		    }
		    	 }
		    }
		});
		
		//ʹ���ڴ���ʾ���м䵯��
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = registerWindow.getSize();
		if (frameSize.height > screenSize.height)
		    frameSize.height = screenSize.height;       
		if (frameSize.width > screenSize.width)
		    frameSize.width = screenSize.width;       
		registerWindow.setLocation((screenSize.width-frameSize.width)/2,(screenSize.height-frameSize.height) / 2);
		
	}
	public boolean checkPassword() {
		  String s1 = new String(passField.getPassword());
		  String s2 = new String(repassField.getPassword());
		  if(s1.equals(s2))
		   return true;
		  else 
		   return false;
		 }
	 public boolean checkEmail() {
		  String s = emailField.getText();
		  if(s.contains("@")&&s.contains(".com"))
		   return true;
		  else
		   return false;
		 }
	 public boolean checkID() {
		  String s = idField.getText();
		  if(s.length() >= 5)
		   return true;
		  else
		   return false;
		 }
	 public boolean checkPasswordLength() {
		  String s = new String(passField.getPassword());
		  if(s.length() >= 6)
		   return true;
		  else
		   return false;
		 }
	 //����������֤���Ƿ���ȷ
	 public void check() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		 String inputValue = JOptionPane.showInputDialog("����������䷢����֤�ʼ�����鿴��������֤��");
 		 if(inputValue == null)
           {
              return;
           }
 		 if(inputValue.equals(String.valueOf(Sendmail.random))){
 			 JOptionPane.showMessageDialog(null, "��ϲ��ע��ɹ�,Pet House ������500Ԫ����ȯ�����ڷ��ص�¼ҳ��","",JOptionPane.INFORMATION_MESSAGE);
 			 String s1 = new String(passField.getPassword());
 			 UserInfo u = new UserInfo(idField.getText(), s1, emailField.getText(), 500);
 			 //д�����ݿ�
 			 Connection conn;  
 			 Statement stmt;
 			 Class.forName("com.mysql.jdbc.Driver").newInstance(); 
 			 conn = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/heavy's", "root", "123456");
 			 //ִ��SQL��� 
 			 stmt = (Statement) conn.createStatement();
 			 stmt.execute("insert into UserInfo (�û���,����,����,���) value ('"+u.getName()+"','"+u.getPassword()+"','"+u.getEmail()+"', '500')");
 			 registerWindow.setVisible(false);
 			 new logInWindow();
 		 }
 		 else {
 			 JOptionPane.showMessageDialog(null, "��֤�����!","",JOptionPane.INFORMATION_MESSAGE);
 			 check();
 		 }
		 
	 }
	 //����û����Ƿ����
	 public boolean checkExist(){
		 	DataReader.sql = "select *from userinfo";//SQL���
			DataReader b = new DataReader(DataReader.sql);
			b.readUserInfo();
			for(UserInfo str : DataReader.Userinfo){
				if(str.getName().equals(idField.getText())){
					return true;
				}
			}
			return false;
			
	 }
}
