import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class petWindow {
	private JFrame petWindow;
	private JButton backButton,cartButton,evaluateButton;
	private JLabel background,ldog,lcat,lhamster,lparrot,lfish,lrabbit,lsquirrel,lcanary,lturtle,llizard,lmyna,lsnake,lprice,lprice2;
	private Icon iconBackground,iconDog,iconCat,iconHamster,iconParrot,iconFish,iconRabbit,iconSquirrel,iconCanary,iconTurtle,iconLizard,iconMyna,iconSnake;
	private JTextArea petInfoArea,evaluationArea;
	private JScrollPane jsp;
	public static int cartLocation = 0;
	public static int total = 0;
	private String name;
	public petWindow(){
		petWindow = new JFrame("Pet House");
		petWindow.setSize(900, 600);
		petWindow.setLayout(null);
		petWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		petWindow.setVisible(true);
		petWindow.setResizable(false);
		
		backButton = new JButton("Back");
		backButton.setBounds(780, 500, 80, 30);
		backButton.setFocusPainted(false);
		//backButton.setContentAreaFilled(false);
		backButton.setDoubleBuffered(true);
		backButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		evaluateButton = new JButton("Evaluate");
		evaluateButton.setBounds(672, 500, 105, 30);
		evaluateButton.setFocusPainted(false);
		evaluateButton.setDoubleBuffered(true);
		evaluateButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		cartButton = new JButton("Add to Cart");
		cartButton.setBounds(90, 270, 150, 30);
		cartButton.setFocusPainted(false);
		cartButton.setContentAreaFilled(false);
		cartButton.setDoubleBuffered(true);
		cartButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		petInfoArea = new JTextArea();
		jsp = new JScrollPane(petInfoArea);//������
		jsp.setBounds(280, 110, 500, 300);
		//petInfoArea.setBounds(280,110,500,300);
		petInfoArea.setBackground (new Color(240,249,249));
		petInfoArea.setBorder(new LineBorder(Color.lightGray));
		petInfoArea.setFont(new Font("Microsoft YaHei UI Light", Font.BOLD, 20));
		petInfoArea.setEditable(false);//�����ı��򲻿ɱ��û��༭
		
		evaluationArea = new JTextArea();
		evaluationArea.setBounds(280, 415, 500, 80);
		evaluationArea.setBackground (new Color(240,249,249));
		evaluationArea.setBorder(new LineBorder(Color.lightGray));
		evaluationArea.setFont(new Font("Microsoft YaHei UI Light", Font.BOLD, 20));
		
		background = new JLabel();
		background.setBounds(0, 0, 900, 600);
		iconBackground = new ImageIcon(this.getClass().getResource("2.jpg"));
		background.setIcon(iconBackground);
		
		lprice = new JLabel("RMB");
		lprice.setBounds(160, 190, 50, 121);
		lprice2 = new JLabel("");
		lprice2.setBounds(130, 190, 40, 121);
		
		ldog = new JLabel();
		ldog.setBounds(100, 110, 121, 121);
		iconDog = new ImageIcon(this.getClass().getResource("dog.jpg"));
		ldog.setIcon(iconDog);
		
		lcat = new JLabel();
		lcat.setBounds(100, 110, 121, 121);
		iconCat = new ImageIcon(this.getClass().getResource("cat.jpg"));
		lcat.setIcon(iconCat);
		
		lhamster = new JLabel();
		lhamster.setBounds(100, 110, 121, 121);
		iconHamster = new ImageIcon(this.getClass().getResource("hamster.jpg"));
		lhamster.setIcon(iconHamster);
		
		lparrot = new JLabel();
		lparrot.setBounds(100, 110, 121, 121);
		iconParrot = new ImageIcon(this.getClass().getResource("parrot.jpg"));
		lparrot.setIcon(iconParrot);
		
		lfish = new JLabel();
		lfish.setBounds(100, 110, 121, 121);
		iconFish = new ImageIcon(this.getClass().getResource("fish.jpg"));
		lfish.setIcon(iconFish);
		
		lrabbit = new JLabel();
		lrabbit.setBounds(100, 110, 121, 121);
		iconRabbit = new ImageIcon(this.getClass().getResource("rabbit.jpg"));
		lrabbit.setIcon(iconRabbit);
		
		lsquirrel = new JLabel();
		lsquirrel.setBounds(100, 110, 121, 121);
		iconSquirrel = new ImageIcon(this.getClass().getResource("squirrel.jpg"));
		lsquirrel.setIcon(iconSquirrel);
		
		lcanary = new JLabel();
		lcanary.setBounds(100, 110, 121, 121);
		iconCanary = new ImageIcon(this.getClass().getResource("canary.jpg"));
		lcanary.setIcon(iconCanary);
		
		lturtle = new JLabel();
		lturtle.setBounds(100, 110, 121, 121);
		iconTurtle = new ImageIcon(this.getClass().getResource("turtle.jpg"));
		lturtle.setIcon(iconTurtle);
		
		llizard = new JLabel();
		llizard.setBounds(100, 110, 121, 121);
		iconLizard = new ImageIcon(this.getClass().getResource("lizard.jpg"));
		llizard.setIcon(iconLizard);
		
		lmyna = new JLabel();
		lmyna.setBounds(100, 110, 121, 121);
		iconMyna = new ImageIcon(this.getClass().getResource("myna.jpg"));
		lmyna.setIcon(iconMyna);
		
		lsnake = new JLabel();
		lsnake.setBounds(100, 110, 121, 121);
		iconSnake = new ImageIcon(this.getClass().getResource("snake.jpg"));
		lsnake.setIcon(iconSnake);
		
		//�������ذ�ť����¼�
		backButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {	
            	mainWindow.flag = 0;
            	petWindow.setVisible(false);
            	new mainWindow();
            }
        });
		//�������ﳵ��ť����¼�
				cartButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	cartLocation++;
		            	if(cartLocation <= 5){
		            		petWindow.setVisible(false);
		            		new cartWindow();
		            		total = total + Integer.valueOf(lprice2.getText());
		            	}
		            	else JOptionPane.showMessageDialog(null, "Your shopping cart is full,can't add now.","",JOptionPane.WARNING_MESSAGE);
		            }
		        });
		petWindow.add(lprice);
		petWindow.add(lprice2);
		petWindow.add(evaluateButton);
		petWindow.add(backButton);
		petWindow.add(jsp);
		petWindow.add(evaluationArea);
		petWindow.add(cartButton);
		if(mainWindow.flag == 1){
			petWindow.add(ldog);
			petWindow.add(background);
			name = "dog";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("dog")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 2){
			petWindow.add(lcat);
			petWindow.add(background);
			name = "cat";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("cat")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 3){
			petWindow.add(lhamster);
			petWindow.add(background);
			name = "hamster";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("hamster")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 4){
			petWindow.add(lparrot);
			petWindow.add(background);
			name = "parrot";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("parrot")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 5){
			petWindow.add(lfish);
			petWindow.add(background);
			name = "fish";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("fish")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 6){
			petWindow.add(lrabbit);
			petWindow.add(background);
			name = "rabbit";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("rabbit")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 7){
			petWindow.add(lsquirrel);
			petWindow.add(background);
			name = "squirrel";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("squirrel")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 8){
			petWindow.add(lcanary);
			petWindow.add(background);
			name = "canary";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("canary")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 9){
			petWindow.add(lturtle);
			petWindow.add(background);
			name = "turtle";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("turtle")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 10){
			petWindow.add(llizard);
			petWindow.add(background);
			name = "lizard";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("lizard")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 11){
			petWindow.add(lmyna);
			petWindow.add(background);
			name = "myna";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("myna")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else if(mainWindow.flag == 12){
			petWindow.add(lsnake);
			petWindow.add(background);
			name = "snake";
				for(PetInfo str : DataReader.info){
					if(str.getName().equals("snake")){
						petInfoArea.setText(str.toString());
						lprice2.setText(String.valueOf(str.getPrice()));
						for(String s : str.getEvaluation().split("&")){
							petInfoArea.append("     "+s+"\n");
						}
					}
			}
		}
		else ;
		//�������۰�ť����¼�
				evaluateButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e)
		            {	
		            	String evalue = evaluationArea.getText();
		            	if(evalue.length() >= 5){
			            	for(PetInfo str : DataReader.info){
								if(str.getName().equals(name)){
									evalue =str.getEvaluation()+ " &" +logInWindow.userinfo.getName()+" says: " +evalue;
									JOptionPane.showMessageDialog(null, "�������ύ","",JOptionPane.WARNING_MESSAGE);
									 try {
										write(str.getName(),evalue);
									} catch (InstantiationException | IllegalAccessException | ClassNotFoundException
											| SQLException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
								}
								
			            	}
			            	DataReader.sql = "select *from pet";//SQL���
			        		DataReader a = new DataReader(DataReader.sql);
			        		a.read();
			            	petWindow.setVisible(false);
			            	evaluationArea.setText("");
			            	evalue="";
			            	name = "";
			            	petInfoArea.setText("");
			            	new petWindow();
		            	}
		            	else JOptionPane.showMessageDialog(null, "������������","",JOptionPane.WARNING_MESSAGE);
		            	
		            }
		        });
		
		
		//ʹ���ڴ���ʾ���м䵯��
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = petWindow.getSize();
		if (frameSize.height > screenSize.height)
		    frameSize.height = screenSize.height;       
		if (frameSize.width > screenSize.width)
		    frameSize.width = screenSize.width;       
		petWindow.setLocation((screenSize.width-frameSize.width)/2,(screenSize.height-frameSize.height) / 2);
	}
	public void write(String name,String evalue)throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		//д�����ݿ�
    	Connection conn;  
    	Statement stmt;
    	Class.forName("com.mysql.jdbc.Driver").newInstance(); 
    	conn = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/heavy's", "root", "123456");
    	//ִ��SQL��� 
    	stmt = (Statement) conn.createStatement();
    	String sql = "update pet set evaluation = '"+ evalue + "'where name ='"+name+"'";
		 stmt.execute(sql);
	}
}
