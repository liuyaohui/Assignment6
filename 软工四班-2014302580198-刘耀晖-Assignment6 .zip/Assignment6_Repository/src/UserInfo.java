
public class UserInfo {
	private String name;
	private String password;
	private String email;
	private int balance;
	public UserInfo(String name,String password,String email,int balance){
		this.name = name;
		this.password = password;
		this.email = email;
		this.balance = balance;
	}
	public void setName(String name){
		this.name = name;
	}
	public String getName(){
		return name;
	}
	public void setPassword(String password){
		this.password = password;
	}
	public String getPassword(){
		return password;
	}
	public void setEmail(String email){
		this.email = email;
	}
	public String getEmail(){
		return email;
	}
	public void setBalance(int balance){
		this.balance = balance;
	}
	public int getBalance(){
		return balance;
	}
}
