
public class PetInfo {
	private String name;
	private String eat;
	private String drink;
	private String live;
	private String hobby;
	private int price;
	private String evaluation;
	public PetInfo(String name,String eat,String drink,String live,String hobby,int price,String evaluation){
		this.name = name;
		this.eat = eat;
		this.drink = drink;
		this.live = live;
		this.hobby = hobby;
		this.price = price;
		this.evaluation = evaluation;
	}
	@Override
	public String toString() {
		return "\n    My name is " + name + ".\n\n" + "    I eat "+ eat + ".\n\n" + "    I drink " + drink + ".\n\n" + "    Where I live : "
				+ live + "\n\n    My hobby : " + hobby + "\n------------------------------------------------\n    Evaluation :\n";
	}
	public void setEvaluation(String evaluation){
		this.evaluation = evaluation;
	}
	public String getEvaluation(){
		return evaluation;
	}
	public void setName(String name){
		this.name = name;
	}
	public String getName(){
		return name;
	}
	public void setEat(String eat){
		this.eat = eat;
	}
	public String getEat(){
		return eat;
	}
	public void setDrink(String drink){
		this.drink = drink;
	}
	public String getDrink(){
		return drink;
	}
	public void setLive(String live){
		this.live = live;
	}
	public String getLive(){
		return live;
	}
	public void setHobby(String hobby){
		this.hobby = hobby;
	}
	public String getHobby(){
		return hobby;
	}
	public void setPrice(int price){
		this.price = price;
	}
	public int getPrice(){
		return price;
	}
}
