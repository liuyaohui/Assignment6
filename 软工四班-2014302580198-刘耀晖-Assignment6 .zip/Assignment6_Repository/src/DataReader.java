import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class DataReader {
	public static final String url = "jdbc:mysql://127.0.0.1/heavy's";//�ҵ�URl
	//public static final String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";//����URL
	public static final String name = "com.mysql.jdbc.Driver";
	public static final String user = "root";
	public static final String password = "123456";
	
	public static List<PetInfo> info = new ArrayList<PetInfo>();
	public static List<UserInfo> Userinfo = new ArrayList<UserInfo>();
	public Connection conn = null;
	public PreparedStatement pst = null;
	
	static String sql = null;
	static DataReader db = null;
	static ResultSet ret = null;
	
	public DataReader(String sql){
		try{
			Class.forName(name);//ָ����������
			conn = (Connection) DriverManager.getConnection(url, user, password);
			pst = (PreparedStatement) conn.prepareStatement(sql);//׼��ִ�����
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void close(){
		try{
			this.conn.close();
			this.pst.close();
		}catch(SQLException e){
			e.getStackTrace();
		}
	}
	public void read(){
		db = new DataReader(sql);//����DataReader����
		try{
			ret = db.pst.executeQuery();//ִ����䣬�õ������ 
			while (ret.next()){
				String name = ret.getString(2);
				String eat = ret.getString(3);
				String drink = ret.getString(4);
				String live = ret.getString(5);
				String hobby = ret.getString(6);
				int price = ret.getInt(7);
				String evaluation = ret.getString(8);
				PetInfo PetInfo = new PetInfo(name,eat,drink,live,hobby,price,evaluation);
				PetInfo.setName(name);
				PetInfo.setEat(eat);
				PetInfo.setDrink(drink);
				PetInfo.setLive(live);
				PetInfo.setHobby(hobby);
				PetInfo.setPrice(price);
				PetInfo.setEvaluation(evaluation);
				
				info.add(PetInfo);
				
			}//��ʾ����
			ret.close();
			db.close();//�ر�����
			
			//��ӡProfessorInfo
//			for(PetInfo str:info){
//			    System.out.println(str.toString());
//			    }
			
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	public void readUserInfo(){
		db = new DataReader(sql);//����DataReader����
		try{
			ret = db.pst.executeQuery();//ִ����䣬�õ������ 
			while (ret.next()){
				String name = ret.getString(1);
				String password = ret.getString(2);
				String email = ret.getString(3);
				int balance = ret.getInt(4);
				UserInfo UserInfo = new UserInfo(name,password,email,balance);
				UserInfo.setName(name);
				UserInfo.setPassword(password);
				UserInfo.setEmail(email);
				UserInfo.setBalance(balance);
				
				Userinfo.add(UserInfo);
				
			}//��ʾ����
			ret.close();
			db.close();//�ر�����
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
	
	}
}
