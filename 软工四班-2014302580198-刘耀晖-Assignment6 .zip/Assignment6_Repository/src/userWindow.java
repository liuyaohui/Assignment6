import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class userWindow {
	private JFrame userWindow;
	private JLabel lId,lEmail,lBalance;
	private JButton backButton;
	private JLabel jId,jBalance,jEmail,jBackground;
	private Icon iconBG;
	public userWindow(){
		userWindow = new JFrame("Pet House");
		userWindow.setSize(800, 500);
		userWindow.setLayout(null);
		userWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		userWindow.setVisible(true);
		userWindow.setResizable(false);
		
		lId = new JLabel(logInWindow.userinfo.getName());
		lId.setBounds(550, 130, 190, 30);
		lId.setFont(new Font("Tahoma", Font.BOLD, 13));
		lEmail = new JLabel(logInWindow.userinfo.getEmail());
		lEmail.setBounds(550, 170, 190, 30); 
		lEmail.setFont(new Font("Tahoma", Font.BOLD, 13));
		lBalance = new JLabel(String.valueOf(logInWindow.userinfo.getBalance()));
		lBalance.setBounds(550, 210, 190, 30);
		lBalance.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		jId = new JLabel("Username:");
		jBalance = new JLabel("Balance:");
		jEmail = new JLabel("E-mail:");
		jId.setBounds(480,130,70,30);
		jEmail.setBounds(480,170,70,30);
		jBalance.setBounds(480,210,70,30);
		jId.setFont(new Font("Tahoma", Font.BOLD, 13));
		jBalance.setFont(new Font("Tahoma", Font.BOLD, 13));
		jEmail.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		backButton = new JButton("Back");
		backButton.setBounds(570, 260, 90, 30);
		backButton.setFocusPainted(false);
		backButton.setContentAreaFilled(false);
		backButton.setDoubleBuffered(true);
		backButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		jBackground = new JLabel();
		jBackground.setBounds(0, 0, 800, 500);
		iconBG = new ImageIcon(this.getClass().getResource("1.jpg"));
		jBackground.setIcon(iconBG);
		
		userWindow.add(backButton);
		userWindow.add(lId);
		userWindow.add(lEmail);
		userWindow.add(lBalance);
		userWindow.add(jId);
		userWindow.add(jBalance);
		userWindow.add(jEmail);
		userWindow.add(jBackground);
		
		//�������ذ�ť����¼�
				backButton.addActionListener(new ActionListener() {

		            public void actionPerformed(ActionEvent e)
		            {	
		            	userWindow.setVisible(false);
		            	new mainWindow();
		            }
		        });
		
		//ʹ���ڴ���ʾ���м䵯��
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = userWindow.getSize();
		if (frameSize.height > screenSize.height)
				 frameSize.height = screenSize.height;       
		if (frameSize.width > screenSize.width)
				 frameSize.width = screenSize.width;       
		userWindow.setLocation((screenSize.width-frameSize.width)/2,(screenSize.height-frameSize.height) / 2);
	}
}
